<?php include ( "connect.php" ); ?>
<?php 
ob_start();
session_start();
if (!isset($_SESSION['user_id'])) {
	$user = "";
}
else {
	$user = $_SESSION['user_id'];
	$result = mysql_query("SELECT * FROM Users WHERE userName='$user'");
	$get_user_email = mysql_fetch_assoc($result);
	$uname_db = $get_user_email['firstName'];
}
if (isset($_REQUEST['pid'])) {
	
	$pid = mysql_real_escape_string($_REQUEST['pid']);
}else {
	header('location: index.php');
}


$getposts = mysql_query("SELECT * FROM Products WHERE id ='$pid'") or die(mysql_error());
if (mysql_num_rows($getposts)) {
	$row = mysql_fetch_assoc($getposts);
	$id = $row['id'];
	$pName = $row['name'];
	$price = $row['price'];
	$description = $row['description'];
	$picture = $row['photo'];
	$item = $row['type'];
	$discount =$row['discount'];
	$fPrice=$price-($price*$discount)/100;
}	

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>View Products</title>
	<link  href="../css/new.css" rel="stylesheet"/>
	<style>
	#form1{
		position:absolute;
		border-left: 6px solid yellow;
		background-color: deepskyblue;
		height:auto;
		/*width:100%;*/
		font-size:30px;
		top:30%;
		margin:auto;
		margin-left:10%;
		width:75%;
		color:white;
		word-spacing:5px;
		padding:25px;
		/*opacity: 0.8;*/
	}
	#form2{
		text-align:center;
		margin-bottom: 10px;
	}

	img {
		border: 1px solid #ddd;
		border-radius: 4px;
		padding: 5px;
		width: 150px;
	}
</style>
</head>
<body>
	<div id="full">
		<div id="header">
			<div id="logo">
				<a href="../index.php"><?php echo "ShopWithUs" ;?></a>
			</div>
			<div id="lin">
       <a href="../index.php" class="link" > Home &nbsp; &nbsp;</a> 
       <a href="../products/products.php" class="link"> Products  &nbsp; &nbsp;</a> 
       <a href="../about.php" class="link"> About Us  &nbsp;</a> 
       <a href="../contact.php" class="link"> Contact Us </a> 
       <?php 
       if ($user!="") {
         echo '<a style="text-decoration: none;  position:absolute; right:0; padding-right: 170px;color: yellow;" href="../profile.php?uid='.$user.'">' .$user.'&nbsp; &nbsp;</a>';
       }
       else {
         echo '<a style="text-decoration: none; position:absolute; right:0; padding-right: 170px;color: yellow;" href="../login.php">Login &nbsp; &nbsp;</a>';
       }
       ?>

       <?php 
       if ($user!="") {
         echo '<a style="text-decoration: none; position:absolute; right:0; padding-right: 55px; color: #fff;" href="../logout.php">Logout  &nbsp; &nbsp; </a>';
       }
       else {
         echo '<a style="text-decoration: none; position:absolute; right:0; padding-right: 55px;color: #fff;" href="../register.php">Register &nbsp; &nbsp;</a>';
       }
       ?>

     </div>
		</div>
		<div id="marquee">
			<marquee> Welcome to world's most famous shopping site. </marquee>
		</div>

		<div id="form1">
			<?php 
			echo '
			<div style="float: left;">
				<div>
					<img src="../img/'.$item.'/'.$picture.'" style=" margin-top:20px; margin-left: 40px; height: 500px; width: 450px; padding: 2px; border: 2px solid yellow;">
				</div>
			</div>

			<div style="float: right; margin-right:50px; margin-top:20px; height:500px; width: 40%;color: #067165; background-color: #fcff6e ;padding: 10px;">
				<div style="">
					<h3 style="font-size: 20px; font-weight: bold; text-align: center">'.$pName.'</h3><hr>
					<h3 style="padding: 5px 0 0 0; font-size: 20px;">Price: Rs. '.$price.'</h3><hr>
					<h3 style="padding: 5px 0 0 0; font-size: 20px;">Discount: '.$discount.' %</h3><hr>
					<h3 style="padding: 5px 0 0 0; font-size: 20px;">Final Price: Rs. '.$fPrice.' </h3><hr>
					<h3 style="padding: 5px 0 0 0; font-size: 22px; ">Description:</h3>
					<p style="font-size: 20px">
						'.$description.'
					</p>

					<div>
						
						<div id="srcheader">
							<form id="" method="post" action="../addCart.php?poid='.$pid.'">
								<input type="submit" value="Add to cart" class="srcbutton" >
							</form>

							<div class="srcclear"></div>
						</div>
						
						<div id="srcheader" style="margin-top:5px;">
							<form id="" method="post" action="../enterReview.php?poid='.$pid.'">
								<input type="submit" value="Enter Review" class="srcbutton" >
							</form>
							<div class="srcclear"></div>
						</div>
					</div>
				</div>
			</div>
			';
			?>
			<!-- <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/> -->
			<div id="review">

				<h3> Review of the Products : </h3>
				<?php
				$getposts = mysql_query("SELECT * FROM Reviews WHERE productId ='$pid'") or die(mysql_error());
				if (mysql_num_rows($getposts)) {
					while ($row = mysql_fetch_assoc($getposts)) {
						$userNa=$row['userName'];
						$re=$row['review'];
						echo '<div style="text-align: left; padding: 0 0 6px 0; color:black;"> <span style="font-size: 40px; color:black;">'.$userNa.' : </span> '.$re.'</div>';
					}
				}
				?>
			</div>
			<br/><br/><br/><br/><br/><br/>
			<h2 style="color:white;">Recommended Products for you</h2>
			<?php 
			$getposts = mysql_query("SELECT * FROM Products WHERE  id != '".$pid."' AND type ='".$item."'  ORDER BY RAND() LIMIT 3") or die(mysql_error());
			if (mysql_num_rows($getposts)) {
				echo '<ul id="recs">';
				while ($row = mysql_fetch_assoc($getposts)) {
					$id = $row['id'];
					$pName = $row['name'];
					$price = $row['price'];
					$description = $row['description'];
					$picture = $row['photo'];
					$discount =$row['discount'];
					$fPrice=$price-($price*$discount)/100;
					echo '
						<ul style="float: left;">
						<li style="float: left; padding: 0px 25px 25px 25px;">
						<div class="home-prodlist-img"><a href="view_product.php?pid='.$id.'">
							<img src="../img/'.$item.'/'.$picture.'" class="home-prodlist-imgi">
							</a>
							<div style="text-align: center; padding: 0 0 6px 0; color:black;"> <span style="font-size: 15px; color:black;">'.$pName.'</span><br> Price: '.$price.' Rs</div>
							<div style="text-align: center; padding: 0 0 6px 0; color:black;"> <span style="font-size: 15px; color:black;"> Discount : '.$discount.' %</span><br> Final Price: '.$fPrice.' Rs</div>
						</div>
						</li>
						</ul>
					';

				}
			}
			?>
		</div>

	</div>
</body>
</html>
