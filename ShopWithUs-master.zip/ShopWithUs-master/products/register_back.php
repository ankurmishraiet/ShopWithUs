<?php
 session_start();
 require('function.php');
 $fname = validate($_POST["firstName"]);
 $lname = validate($_POST["lastName"]);
 $user_id = validate($_POST["userName"]);
 $email_id = validate($_POST["emailId"]);
 $mno = validate($_POST["mobileNo"]);
 $add1 = validate($_POST["address"]);
 $gender = validate($_POST["gender"]);
 $pass = validate($_POST["password"]);
 $con=con();
  
  $query="select *from Users s where s.userName='$user_id'";
  $result=$con->query($query);
  if($result->num_rows>0)
   {
     echo "<script>alert('User with this user id is exist.');window.location='register.php';</script>";
        die();
   }
   else
    {
     $ins_query="insert into Users values('$user_id','$fname','$lname',$mno,'$email_id','$add1','$gender','$pass')";
     $ins_result=$con->query($ins_query);
     
     echo "<script>alert('Congratulations !!! Now you are a valid customer.');window.location='login.php';</script>";
	 die(); 
    }
?>
