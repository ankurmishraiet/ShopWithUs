<?php include ( "../function.php" ); ?>
<?php 
ob_start();
$con=con();
session_start();
if (!isset($_SESSION['user_id'])) {
	$user = "";
}
else {
	$user = $_SESSION['user_id'];
	//$result = mysql_query("SELECT * FROM Users WHERE userName='$user'");
	// $sql="select * from Users where userName='$user' ";
	 //$result=$con->query($sql);
		//$get_user_email = mysql_fetch_assoc($result);
			//$uname_db = $get_user_email['firstName'];
	//echo '$user';
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title>T Shirt Products</title>
	<link  href="../css/new.css" rel="stylesheet"/>
	<style>
	#form1{
		position:absolute;
		border-left: 6px solid yellow;
		background-color: deepskyblue;
		height:auto;
		/*width:100%;*/
		font-size:30px;
		top:30%;
		margin:auto;
		margin-left:10%;
		width:75%;
		color:white;
		word-spacing:5px;
		padding:25px;
		/*opacity: 0.8;*/
	}
	#form2{
		text-align:center;
		margin-bottom: 10px;
	}

	img {
		border: 1px solid #ddd;
		border-radius: 4px;
		padding: 5px;
		width: 150px;
	}
</style>
</head>
<body>
	<div id="full">
		<div id="header">
			<div id="logo">
				<a href="../index.php"><?php echo "ShopWithUs" ;?></a>
			</div>
			<div id="lin">
				<a href="../index.php" class="link" > Home &nbsp; &nbsp;</a> 
				<a href="../products/products.php" class="link"> Products  &nbsp; &nbsp;</a> 
				<a href="../about.php" class="link"> About Us  &nbsp;</a> 
				<a href="../contact.php" class="link"> Contact Us </a>
				<?php 
				if ($user!="") {
					echo '<a style="text-decoration: none;  position:absolute; right:0; padding-right: 170px;color: yellow;" href="../profile.php?uid='.$user.'">' .$user.'&nbsp; &nbsp;</a>';
				}
				else {
					echo '<a style="text-decoration: none; position:absolute; right:0; padding-right: 170px;color: yellow;" href="../login.php">Login &nbsp; &nbsp;</a>';
				}
				?>

				<?php 
				if ($user!="") {
					echo '<a style="text-decoration: none; position:absolute; right:0; padding-right: 55px; color: #fff;" href="../logout.php">Logout  &nbsp; &nbsp; </a>';
				}
				else {
					echo '<a style="text-decoration: none; position:absolute; right:0; padding-right: 55px;color: #fff;" href="../register.php">Register &nbsp; &nbsp;</a>';
				}
				?>

			</div>
		</div>
		<div id="marquee">
			<marquee> Welcome to world's most famous shopping site. </marquee>
		</div>

		<div id="form1">
			<?php 
			//$getposts = mysql_query("SELECT * FROM Products WHERE  type='Beauty'  ORDER BY id DESC LIMIT 10") or die(mysql_error());
			$sql = "SELECT * FROM Products WHERE  type='Tshirt'  ORDER BY id DESC LIMIT 10";
			$result=$con->query($sql);
					//if ($row=$result->fetch_array()) {
					//echo '<ul id="recs">';
					//echo "Database Has been selected";
			while ($row=$result->fetch_array()) {
				$id = $row['id'];
						//echo "Data Base Has been selected";
				$pName = $row['name'];
				$price = $row['price'];
				$description = $row['description'];
				$picture = $row['photo'];
				$discount =$row['discount'];
				$fPrice=$price-($price*$discount)/100;
				echo '
				<ul style="float: left;list-style: none">
				<li style="float: left; padding: 0px 25px 25px 25px;">
				<div class="home-prodlist-img"><a href="view_product.php?pid='.$id.'">
				<img src="../img/Tshirt/'.$picture.'" class="home-prodlist-imgi">
				</a>
				<div style="text-align: center; padding: 0 0 6px 0; color:black;"> <span style="font-size: 15px; color:black;">'.$pName.'</span><br> Price: '.$price.' Rs</div>
				<div style="text-align: center; padding: 0 0 6px 0; color:black;"> <span style="font-size: 15px; color:black;"> Discount : '.$discount.' %</span><br> Final Price: '.$fPrice.' Rs</div>
				<div>
				</div>

				</li>
				</ul>
				';

			}
				//}
				//else {
				  //  echo "No DataBase Has Been Selected";
				//}
			?>


		</div>

	</div>
</body>
</html>
