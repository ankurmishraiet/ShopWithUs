<?php
session_start();
require './phpmailer/PHPMailerAutoload.php';

//create an instance of php mailer
$mail = new PHPMailer();

//enable smtp
$mail->isSMTP();

//set a host
$mail->Host = "smtp.gmail.com";

//set type of protection
$mail->SMTPSecure = "ssl";//if TLS,port=465
$mail->Port = 465;

//set authentication to true
$mail->SMTPAuth = true;

//login details for account
$mail->Username = 'nitishsihmar.mca2017.mnnit@gmail.com';
$mail->Password = 'NSihmar24#';

$mail->setFrom('nitishsihmar.mca2017.mnnit@gmail.com', 'ShopWithUs');
//$mail->addAddress($_SESSION["email"]);
// $mail->addAddress($_SESSION["email"]);
$mail->addAddress("sihmar.nitish@gmail.com","Nitish Sihmar");
//setting up the subject
$mail->Subject = 'Order Confirmation';

//setting body for mail
$mail->Body = 'Thanks for placing order with ShopWithUs.
'; // Our message above including the link
 

if ($mail->send())
	echo "Email";
// echo "<script> location.href='../profile.php'; </script>";
else
echo "Done";


?>
